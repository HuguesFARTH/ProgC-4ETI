# Bibliothèques
* stdio.h
* stdlib.h
* time.h

# Références
* https://stackoverflow.com/
* Cours
* https://github.com/HuguesFARTH/ProgC-4ETI

# Difficulté
* Facile

# Commentaires
*
