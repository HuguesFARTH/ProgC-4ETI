# Bibliothèques
* stdio.h
* stdlib.h
* time.h
* string.h
* tplib.c (ficier contenant différentes fonctions utiles)
* hashmap.c (semblant de map développé par nos soins facilitant l'exercice "couleur_compteur.c")

# Références
* https://stackoverflow.com/
* Cours
* https://github.com/HuguesFARTH/ProgC-4ETI

# Difficulté
* Moyen

# Commentaires
* Pour l'exercice "couleur_compteur.c" nous avons créé un semblant de map. C'était un très bon exercice sur la compréhension de l'allocution mémoire.
