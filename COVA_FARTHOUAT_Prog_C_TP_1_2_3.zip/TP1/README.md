# Bibliothèques
* stdio.h
* stdlib.h
* errno.h

# Références
* https://stackoverflow.com/
* Cours
* https://github.com/HuguesFARTH/ProgC-4ETI

# Difficulté
* Facile

# Commentaires
* Possibilité de passer le rayon en paramètre pour cercle.c
