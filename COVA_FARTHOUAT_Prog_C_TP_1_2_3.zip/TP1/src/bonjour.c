#include <stdio.h>

int main() {
  printf("bonjour le monde!");
  return 0;
}
